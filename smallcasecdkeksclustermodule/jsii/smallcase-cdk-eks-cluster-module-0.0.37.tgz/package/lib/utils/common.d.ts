import { Selector } from 'aws-cdk-lib/aws-eks';
import * as eks from 'aws-cdk-lib/aws-eks';
import { AwsCustomResource } from 'aws-cdk-lib/custom-resources';
import { Construct } from 'constructs';
import { InternalMap } from '../constructs/eks-cluster';
export interface NodeLabels {
    [name: string]: string;
}
export declare function ObjToStrMap(obj: any): Map<any, any>;
export declare function GetKubernetesLabels(labels: Map<string, string>): NodeLabels;
export declare function GetFargateProfilesNamespace(namespaces: string[], labels?: InternalMap): Selector[];
export declare function setupClusterLogging(scope: Construct, region: string, cluster: eks.Cluster): AwsCustomResource;
