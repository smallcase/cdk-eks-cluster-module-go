import * as eks from 'aws-cdk-lib/aws-eks';
import { Construct } from 'constructs';
export interface CoreAddonProps extends CoreAddonInternalProps {
    readonly addonVersion?: string;
    readonly configurationValues?: string;
}
interface CoreAddonInternalProps {
    readonly cluster: eks.Cluster;
    readonly addonVersion?: string;
    readonly resolveConflicts?: boolean;
    readonly namespace?: string;
}
interface CoreAddonAbstractProps {
    readonly cluster: eks.Cluster;
    readonly addonName: string;
    readonly addonVersion?: string;
    readonly configurationValues?: string;
    readonly resolveConflicts?: boolean;
    readonly serviceAccountName?: string;
    readonly awsManagedPolicyName?: string;
    readonly namespace?: string;
}
declare abstract class CoreAddonAbstract extends eks.CfnAddon {
    protected constructor(scope: Construct, id: string, props: CoreAddonAbstractProps);
}
export declare class CoreDnsAddon extends CoreAddonAbstract {
    /**
     *
     */
    constructor(scope: Construct, id: string, props: CoreAddonProps);
}
export declare class KubeProxyAddon extends CoreAddonAbstract {
    /**
     *
     */
    constructor(scope: Construct, id: string, props: CoreAddonProps);
}
export {};
