import * as eks from 'aws-cdk-lib/aws-eks';
import { Construct } from 'constructs';
export interface VpcCniAddonProps extends EksManagedAddonProps {
    readonly addonVersion?: VpcCniAddonVersion;
    readonly configurationValues?: string;
}
interface EksManagedAddonProps {
    readonly cluster: eks.Cluster;
    readonly addonVersion?: AddonVersion;
    readonly resolveConflicts?: boolean;
    readonly namespace?: string;
}
declare abstract class AddonVersion {
    readonly version: string;
    static of(version: string): void;
    constructor(version: string);
}
export declare class VpcCniAddonVersion extends AddonVersion {
    /**
     * vpc-cni version 1.6.3
     */
    static readonly V1_6_3: VpcCniAddonVersion;
    /**
     * vpc-cni version 1.7.5
     */
    static readonly V1_7_5: VpcCniAddonVersion;
    /**
     * vpc-cni version 1.7.6
     */
    static readonly V1_7_6: VpcCniAddonVersion;
    /**
     * vpc-cni version 1.7.9
     */
    static readonly V1_7_9: VpcCniAddonVersion;
    /**
     * vpc-cni version 1.7.10
     */
    static readonly V1_7_10: VpcCniAddonVersion;
    /**
     * vpc-cni version 1.8.0
     */
    static readonly V1_8_0: VpcCniAddonVersion;
    /**
     * vpc-cni version 1.9.0
     */
    static readonly V1_9_0: VpcCniAddonVersion;
    /**
     * vpc-cni version 1.9.1
     */
    static readonly V1_9_1: VpcCniAddonVersion;
    /**
     * vpc-cni version 1.9.3
     */
    static readonly V1_9_3: VpcCniAddonVersion;
    /**
     * vpc-cni version 1.10.1
     */
    static readonly V1_10_1: VpcCniAddonVersion;
    /**
     * vpc-cni version 1.10.2
     */
    static readonly V1_10_2: VpcCniAddonVersion;
    /**
     * vpc-cni version 1.10.3
     */
    static readonly V1_10_3: VpcCniAddonVersion;
    /**
     * vpc-cni version 1.11.0
     */
    static readonly V1_11_0: VpcCniAddonVersion;
    /**
     * vpc-cni version 1.11.2
     */
    static readonly V1_11_2: VpcCniAddonVersion;
    /**
    * vpc-cni version 1.11.3
    */
    static readonly V1_11_3: VpcCniAddonVersion;
    /**
    * vpc-cni version 1.11.4
    */
    static readonly V1_11_4: VpcCniAddonVersion;
    /**
    * vpc-cni version 1.12.0
    */
    static readonly V1_12_0: VpcCniAddonVersion;
    /**
   * vpc-cni version 1.12.1
   */
    static readonly V1_12_1: VpcCniAddonVersion;
    /**
  * vpc-cni version 1.12.2
  */
    static readonly V1_12_2: VpcCniAddonVersion;
    /**
  * vpc-cni version 1.12.5
  */
    static readonly V1_12_5: VpcCniAddonVersion;
    /**
   * vpc-cni version 1.12.5.2
   */
    static readonly V1_12_5_2: VpcCniAddonVersion;
    /**
   * vpc-cni version 1.17.1.1
   */
    static readonly V1_17_1_1: VpcCniAddonVersion;
    /**
   * vpc-cni version 1.18.6.1
   */
    static readonly V1_18_6_1: VpcCniAddonVersion;
    /**
   * vpc-cni version 1.19.0.1
   */
    static readonly V1_19_0_1: VpcCniAddonVersion;
    /**
   * vpc-cni version 1.19.2.1
   */
    static readonly V1_19_2_1: VpcCniAddonVersion;
    /**
   * vpc-cni version 1.19.2.5
   */
    static readonly V1_19_2_5: VpcCniAddonVersion;
    /**
   * vpc-cni version 1.19.3.1
   */
    static readonly V1_19_3_1: VpcCniAddonVersion;
    /**
   * vpc-cni version 1.19.5
   */
    static readonly V1_19_5_3: VpcCniAddonVersion;
    /**
   * vpc-cni version 1.20.3
   */
    static readonly V1_20_3_1: VpcCniAddonVersion;
    /**
   * vpc-cni version 1.20.4
   */
    static readonly V1_20_4_1: VpcCniAddonVersion;
    /**
     * Custom add-on version
     * @param version custom add-on version
     */
    static of(version: string): VpcCniAddonVersion;
}
interface EksManagedAddonAbstractProps {
    readonly cluster: eks.Cluster;
    readonly addonName: string;
    readonly addonVersion?: AddonVersion;
    readonly configurationValues?: string;
    readonly resolveConflicts?: boolean;
    readonly serviceAccountName?: string;
    readonly awsManagedPolicyName?: string;
    readonly namespace?: string;
}
declare abstract class EksManagedAddonAbstract extends eks.CfnAddon {
    protected constructor(scope: Construct, id: string, props: EksManagedAddonAbstractProps);
}
export declare class VpcEniAddon extends EksManagedAddonAbstract {
    /**
     *
     */
    constructor(scope: Construct, id: string, props: VpcCniAddonProps);
}
export {};
