import { aws_eks as eks } from 'aws-cdk-lib';
import { Construct } from 'constructs';
export interface CommonHelmChartsProps {
    readonly cluster: eks.ICluster;
    readonly iamPolicyPath?: string[];
    readonly serviceAccounts?: string[];
    readonly helmProps: StandardHelmProps;
    readonly logCharts?: boolean;
    readonly dependentNamespaces?: eks.KubernetesManifest[];
}
export interface StandardHelmProps {
    readonly chartVersion?: string;
    readonly chartName: string;
    readonly chartReleaseName?: string;
    readonly helmRepository?: string;
    readonly localHelmChart?: string;
    readonly namespace?: string;
    readonly createNamespace?: boolean;
    readonly helmValues?: {
        [key: string]: any;
    };
}
export declare class CommonHelmCharts extends Construct {
    constructor(scope: Construct, id: string, props: CommonHelmChartsProps);
}
