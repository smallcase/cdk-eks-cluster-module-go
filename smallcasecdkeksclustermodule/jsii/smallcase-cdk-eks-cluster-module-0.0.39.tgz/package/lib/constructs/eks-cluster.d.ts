import * as ec2 from 'aws-cdk-lib/aws-ec2';
import * as eks from 'aws-cdk-lib/aws-eks';
import * as iam from 'aws-cdk-lib/aws-iam';
import * as kms from 'aws-cdk-lib/aws-kms';
import * as lambda from 'aws-cdk-lib/aws-lambda';
import { Construct } from 'constructs';
import { StandardHelmProps } from './common-helm-charts';
import { VpcCniAddonVersion } from '../constructs/eks-managed-addon';
export interface FargateProfile {
    readonly profileName: string;
    readonly namespaces: string[];
    readonly labels?: InternalMap;
    readonly subnetSelection?: ec2.SubnetSelection;
    readonly podExecutionRole?: iam.Role;
}
export interface NamespaceSpec {
    readonly annotations?: InternalMap;
    readonly labels?: InternalMap;
}
export interface NodeGroupConfig {
    readonly name: string;
    readonly instanceTypes: ec2.InstanceType[];
    readonly minSize: number;
    readonly maxSize: number;
    readonly desiredSize?: number;
    readonly diskSize?: number;
    readonly sshKeyName?: string;
    readonly subnetGroupName: string;
    readonly subnetAz?: string[];
    readonly labels: InternalMap;
    readonly taints: InternalMap;
    readonly tags?: InternalMap;
    readonly nodeAMIVersion?: string;
    readonly amiType?: eks.NodegroupAmiType;
    readonly launchTemplateSpec?: eks.LaunchTemplateSpec;
    readonly capacityType?: eks.CapacityType;
}
export interface InternalMap {
    /**
    * @jsii ignore
    */
    readonly [name: string]: string;
}
export interface ClusterConfig {
    readonly clusterName: string;
    readonly clusterVersion: eks.KubernetesVersion;
    readonly addAutoscalerIam?: boolean;
    readonly defaultCapacity: number;
    readonly kubectlLayer?: lambda.ILayerVersion;
    readonly subnets: InternalMap;
    readonly publicAllowAccess?: string[];
    readonly namespaces?: Record<string, NamespaceSpec>;
    readonly teamMembers: string[];
    readonly albControllerVersion?: eks.AlbControllerVersion;
    readonly teamExistingRolePermission?: Record<string, string>;
    readonly tags: InternalMap;
    readonly nodeGroups: NodeGroupConfig[];
    readonly fargateProfiles?: FargateProfile[];
    readonly argoCD?: ArgoCD;
    readonly commonComponents?: Record<string, ICommonComponentsProps>;
    readonly defaultCommonComponents?: DefaultCommonComponents;
    readonly debugLogs?: boolean;
    readonly deprecateClusterAutoScaler?: boolean;
    readonly skipExternalDNS?: boolean;
}
export interface DefaultCommonComponents {
    readonly externalDns?: DefaultCommonComponentsProps;
    readonly clusterAutoscaler?: DefaultCommonComponentsProps;
    readonly awsEbsCsiDriver?: DefaultCommonComponentsProps;
}
export interface DefaultCommonComponentsProps {
    readonly namespace?: string;
}
export interface ICommonComponentsProps {
    helm: StandardHelmProps;
    serviceAccounts?: string[];
    iamPolicyPath?: string[];
}
export interface ArgoCD {
    readonly assumeRoleArn: string;
    readonly clusterRoleName: string;
}
export interface EKSClusterProps {
    readonly availabilityZones: string[];
    readonly clusterVPC?: ec2.IVpc;
    readonly kmsKey: kms.Key;
    readonly workerSecurityGroup: ec2.SecurityGroup;
    readonly clusterConfig: ClusterConfig;
    readonly addonProps?: AddonProps;
    readonly coreDnsAddonProps?: CoreAddonValuesProps;
    readonly kubeProxyAddonProps?: CoreAddonValuesProps;
    readonly s3CsiAddonProps?: CoreAddonValuesProps;
    readonly efsCsiAddonProps?: CoreAddonValuesProps;
    readonly region: string;
}
export interface AddonProps {
    readonly vpnCniAddonVersion?: VpcCniAddonVersion;
    readonly configurationValues?: string;
}
export interface CoreAddonValuesProps {
    readonly addonVersion?: string;
    readonly configurationValues?: string;
}
export declare class EKSCluster extends Construct {
    readonly cluster: eks.Cluster;
    private props;
    readonly additionalNodegroups: eks.Nodegroup[];
    readonly additionalFargateProfile: eks.FargateProfile[];
    readonly fargateProfiles: FargateProfile[];
    constructor(scope: Construct, id: string, props: EKSClusterProps);
    private addManagedVpcCniAddon;
    addServiceAccountWithIamRole(serviceAccountName: string, serviceAccountNamespace: string, policy: any): void;
    private basicCommonComponents;
}
